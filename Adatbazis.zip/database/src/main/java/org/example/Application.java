package org.example;

import java.io.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.h2.tools.Server;

public class Application {

    public static void main(String[] args) throws Exception {
        startDatabase();
        /*
        File myfile= new File("C:\\Users\\palba\\OneDrive - Debreceni Egyetem\\6.félév\\Szoftverfejlesztés mérnököknek\\Project\\Adatok\\ADATOK.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(myfile)));
        String input;*/
        Komponensek card = new Komponensek();

        try(Komponensek_DAO Vdao = new JpaKomponensek_DAO();){
          /*  List<Komponensek> lista = new ArrayList<Komponensek>();
            while ((input = br.readLine())!=null){
                card = new Komponensek();
                String[] tomb =input.split(";");

                card.setKp_Id(tomb[0]);
                card.setName(tomb[1]);
                card.setPrice(Integer.parseInt(tomb[2]));
                card.setPiece(Integer.parseInt(tomb[3]));

                lista.add(card);*/
                Vdao.saveKomponensek(card);
           // }
        }

        System.out.println("Fut a program: ");
        System.out.println("elérésiut: http://localhost:8082/");
    }

    private static void startDatabase() throws SQLException {
        new Server().runTool("-tcp", "-web", "-ifNotExists");
    }
}
